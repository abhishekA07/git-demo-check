package InvoiceProject;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Iterator;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelDuplicateRowRemover {
    public static void duplicacyRemover(String inputFilePath,String outputFilePath) {
        //String inputFilePath = "D:\\DataForTest1\\FinalOutput.xlsx";
//        String outputFilePath = "D:\\Test1\\FinalOutput.xlsx";
        try {
            // Open input Excel file
            FileInputStream inputWorkbook = new FileInputStream(inputFilePath);
            XSSFWorkbook inputWorkbookObj = new XSSFWorkbook(inputWorkbook);
            Sheet inputSheet = inputWorkbookObj.getSheetAt(0);

            // Create output Excel file and sheet
            XSSFWorkbook outputWorkbookObj = new XSSFWorkbook();
            Sheet outputSheet = outputWorkbookObj.createSheet(inputSheet.getSheetName());

            // List to keep track of seen rows
            ArrayList<String> seenRows = new ArrayList<String>();

            // Iterate over input rows and add unique rows to output sheet
            Iterator<Row> rowIterator = inputSheet.iterator();
            while (rowIterator.hasNext()) {
                Row row = rowIterator.next();
                String rowString = getRowAsString(row);
                boolean isDuplicate = false;
                for (String seenRow : seenRows) {
                    if (seenRow.equals(rowString)) {
                        isDuplicate = true;
                        break;
                    }
                }
                if (!isDuplicate) {
                    seenRows.add(rowString);
                    Row outputRow = outputSheet.createRow(outputSheet.getLastRowNum() + 1);
                    copyRow(row, outputRow);
                }
            }

            // Write output Excel file
            FileOutputStream outputWorkbook = new FileOutputStream(outputFilePath);
            outputWorkbookObj.write(outputWorkbook);
            outputWorkbook.close();
            System.out.println("Output written to " + outputFilePath);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Helper method to convert a row to a string
    private static String getRowAsString(Row row) {
        StringBuilder sb = new StringBuilder();
        Iterator<Cell> cellIterator = row.cellIterator();
        while (cellIterator.hasNext()) {
            Cell cell = cellIterator.next();
            sb.append(cell.toString() + "|");
        }
        return sb.toString();
    }

    // Helper method to copy a row to another row
    private static void copyRow(Row inputRow, Row outputRow) {
        Iterator<Cell> cellIterator = inputRow.cellIterator();
        while (cellIterator.hasNext()) {
            Cell inputCell = cellIterator.next();
            Cell outputCell = outputRow.createCell(outputRow.getLastCellNum() == -1 ? 0 : outputRow.getLastCellNum());
            outputCell.setCellValue(inputCell.toString());
        }
    }
}


