package InvoiceProject;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class DeleteEntryFromPsl {
   @SuppressWarnings("resource")
   public static void main(String args []) throws IOException {
	   String PSLfilePath = "D:\\PSLmerged.xlsx";
//public static void deleteRow(String PDFExcelPath, String sheetName, int rowNumber) throws IOException {
      FileInputStream inputStream = new FileInputStream(new File(PSLfilePath));
      Workbook workbook = new XSSFWorkbook(inputStream);
      String sheetName = "Sheet0";
      Sheet sheet = workbook.getSheet(sheetName);
      if (sheet == null) {
    	  System.out.println("Sheet with name " + sheetName + " does not exist in the workbook");
      }
      // Delete the row
      List<Integer> myList = ListofRowNumbers.createListOfRows();
      for(Integer i:myList)
      {
    	  int rowNumber = i;
	      Row row = sheet.getRow(rowNumber);
	      if (row != null) {
	         sheet.removeRow(row);
	         sheet.shiftRows(rowNumber + 1, sheet.getLastRowNum(), -1);
	         System.out.println("Deletion Successfully done for row: "+i);
	      }
      // Write changes to the file
      FileOutputStream outputStream = new FileOutputStream(PSLfilePath);
      workbook.write(outputStream);
      outputStream.close();
      }
      workbook.close();
      inputStream.close();
   }
}

