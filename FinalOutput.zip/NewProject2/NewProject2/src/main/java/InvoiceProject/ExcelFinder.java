package InvoiceProject;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
public class ExcelFinder {
//    public static void main(String[] args) throws FileNotFoundException, IOException {
	public static void RedundancyRemover(String Path) throws FileNotFoundException, IOException {
        String filePath = "D:\\Test1\\L1.xlsx";
//        String filePath = Path;
        String string1 = "Chechare, Amit";
        String string2 = "Reference Data Services - Hub";
        String string3 = "Parupattegar, Sarvagna";
        String string4 = "Asset Management Services";
        int column1Index = 0; // replace with the index of your desired column (starting from 0)
        int column2Index = 18; // replace with the index of your desired column (starting from 0)
	        List<String> headerList = new ArrayList<String>();
	        headerList.add("Contractor");
	        headerList.add("Project");
	        headerList.add("Cost Center");
	        headerList.add("Week Ending Date");
	        headerList.add("Units");
	        headerList.add("Bill Rate");
	        headerList.add("Gross Amount");
	        headerList.add("Volume Discount");
	        headerList.add("Prompt Pay Discount");
	        headerList.add("Program Fee");
	        headerList.add("Tax Amount");
	        headerList.add("Net Supplier Payable");
	        headerList.add("Statement Date");
	        headerList.add("BeeLine Invoice Number");
	        headerList.add("Amount");
	        headerList.add("Payment Number");
	        headerList.add("Payment Date");
	        headerList.add("Invoice ID");
	        headerList.add("Project Name");
        try (FileInputStream inputStream = new FileInputStream(new File(filePath));
             Workbook workbookInput = new XSSFWorkbook(inputStream)) {
            Sheet sheet = workbookInput.getSheetAt(0); // assuming that you want to read the first sheet

            ArrayList<String[]> matchedRows = new ArrayList<>(); // to store the matched rows

            Iterator<Row> iterator = sheet.iterator();
            while (iterator.hasNext()) {
                Row currentRow = iterator.next();

                Cell column1Cell = currentRow.getCell(column1Index);
                Cell column2Cell = currentRow.getCell(column2Index);

                if (column1Cell != null && column1Cell.getStringCellValue().equals(string1) && column2Cell != null && column2Cell.getStringCellValue().equals(string2)) {
                    // if both columns match the given strings
                    int numColumns = currentRow.getLastCellNum();
                    String[] rowData = new String[numColumns];
                    for (int i = 0; i < numColumns; i++) {
                        Cell cell = currentRow.getCell(i);
                        if (cell != null) {
                            rowData[i] = cell.getStringCellValue();
                        } else {
                            rowData[i] = "";
                        }
                    }
                    matchedRows.add(rowData); // add the row data to the list
                }
                if (column1Cell != null && column1Cell.getStringCellValue().equals(string3) && column2Cell != null && column2Cell.getStringCellValue().equals(string4)) {
                    // if both columns match the given strings
                    int numColumns = currentRow.getLastCellNum();
                    String[] rowData = new String[numColumns];
                    for (int i = 0; i < numColumns; i++) {
                        Cell cell = currentRow.getCell(i);
                        if (cell != null) {
                            rowData[i] = cell.getStringCellValue();
                        } else {
                            rowData[i] = "";
                        }
                    }
                    matchedRows.add(rowData); // add the row data to the list
                }
            }
            
            String outputPath1 = "D:\\DataForTest1\\FinalOutput.xlsx";
            // assume this method returns the list of matched rows
            try (Workbook workbook = new XSSFWorkbook()) {
                Sheet sheet2 = workbook.createSheet("Matched Rows");

                // write the headers
                Row headerRow = sheet2.createRow(0);
                String[] headers = matchedRows.get(0); // assume the first row in the list contains the headers
                for (int i = 0; i < headerList.size(); i++) {
                    Cell cell = headerRow.createCell(i);
                    cell.setCellValue(headerList.get(i));
                }

                // write the matched rows
                int lastRowNum = sheet2.getLastRowNum();
                for (int i = 1; i < matchedRows.size(); i++) {
                	Row dataRow = sheet2.createRow(++lastRowNum);
//                    Row dataRow = sheet2.createRow(i);
                    String[] rowData = matchedRows.get(i);
                    for (int j = 0; j < rowData.length; j++) {
                        Cell cell = dataRow.createCell(j);
                        cell.setCellValue(rowData[j]);
                    }
                }
                // save the workbook to the output file
                try (FileOutputStream outputStream = new FileOutputStream(new File(outputPath1))) {
                    workbook.write(outputStream);
                    String finalOutputPath = "D:\\Test1\\FinalOutput.xlsx";
                    ExcelDuplicateRowRemover.duplicacyRemover(outputPath1,finalOutputPath);
                    System.out.println("Final output is written successfully to: "+finalOutputPath);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }     
        }
 
    }
