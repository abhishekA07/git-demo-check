//package InvoiceProject;
//import java.util.HashMap;
//import java.util.Map;
//import java.util.Map.Entry;
//public class ActualmainMethod {
//	public static void main(String[] args) throws Exception {
//		// TODO Auto-generated method stub
//		MainMethod.StartingClass();
//		String filePath = "D:\\Test1\\L1.xlsx";
//		ExcelFinder.RedundancyRemover(filePath);
////		Map<Integer,String> weekEndDates = new HashMap<Integer, String>();
////		weekEndDates.putAll(Comparator3.getDatesList());
////		java.util.Iterator<Entry<Integer, String>> iterator = weekEndDates.entrySet().iterator();
////	    while (iterator.hasNext()) {
////	        Map.Entry<Integer, String> entry = iterator.next();
////	        Integer key = entry.getKey();
////	        String value = entry.getValue();
////	        System.out.println("Key: " + key + ", Value: " + value);
////	    }
//	}
//}
