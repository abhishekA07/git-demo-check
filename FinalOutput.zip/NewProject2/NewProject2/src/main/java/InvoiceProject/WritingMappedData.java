package InvoiceProject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.*;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class WritingMappedData {
	public static void mappingMethod(Map<String, String> map) throws Exception {
	    // open the Excel file
		String inputfilePath = "D:\\DataForTest1\\WeekEndDateProjectData.xlsx";
		String outputFilePath = "D:\\DataForTest1\\OutputOfWeekEndDateProjectData.xlsx"; 
	    FileInputStream inputStream = new FileInputStream(new File(inputfilePath));
	    Workbook workbook = new XSSFWorkbook(inputStream);

	    // get the sheet object
	    Sheet sheet = workbook.getSheet("Sheet1");
	      Row headerRow = sheet.createRow(0);

	      // create header cells
	      Cell headerCell1 = headerRow.createCell(0);
	      headerCell1.setCellValue("Week Ending Date");

	      Cell headerCell2 = headerRow.createCell(1);
	      headerCell2.setCellValue("Project Name");

	    // find the next empty row in the sheet
	    int rowNum = sheet.getLastRowNum() + 1;

	    // iterate through the key-value pairs in the map
	    for (Map.Entry<String, String> entry : map.entrySet()) {
	        // create a new row in the sheet
	        Row row = sheet.createRow(rowNum++);

	        // create a cell for the key and set its value
	        Cell keyCell = row.createCell(0);
	        keyCell.setCellValue(entry.getKey());

	        // create a cell for the value and set its value
	        Cell valueCell = row.createCell(1);
	        valueCell.setCellValue(entry.getValue());
	    }

	    // write the changes to the Excel file
	    FileOutputStream outputStream = new FileOutputStream(inputfilePath);
	    workbook.write(outputStream);
	    // close the workbook and streams
	    workbook.close();
	    outputStream.close();
	    inputStream.close();
	    ExcelDuplicateRowRemover.duplicacyRemover(inputfilePath,outputFilePath);
	}
}

