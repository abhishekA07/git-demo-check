package InvoiceProject;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class DeletionCheck {
   @SuppressWarnings("resource")
public static void deleteRow(String PDFExcelPath, String sheetName, int rowNumber) throws IOException {
      FileInputStream inputStream = new FileInputStream(new File(PDFExcelPath));
      Workbook workbook = new XSSFWorkbook(inputStream);
      Sheet sheet = workbook.getSheet(sheetName);
      if (sheet == null) {
    	  System.out.println("Sheet with name " + sheetName + " does not exist in the workbook");
      }
      // Delete the row
      Row row = sheet.getRow(rowNumber);
      if (row != null) {
         sheet.removeRow(row);
         sheet.shiftRows(rowNumber + 1, sheet.getLastRowNum(), -1);
         System.out.println("Deletion Successfully done.");
      }
      // Write changes to the file
      FileOutputStream outputStream = new FileOutputStream(PDFExcelPath);
      workbook.write(outputStream);
      outputStream.close();
      workbook.close();
      inputStream.close();
   }
}

