package InvoiceProject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Comparator4 {
    public static void main(String[] args) throws Exception {
        // Open the first file
    	String file1Path = "D:\\DataForTest1\\OutputOfWeekEndDateProjectData.xlsx";
    	String file2Path = "D:\\PSLmerged.xlsx";
        FileInputStream file1 = new FileInputStream(new File(file1Path));
        XSSFWorkbook workbook1 = new XSSFWorkbook(file1);
        Sheet sheet1 = workbook1.getSheetAt(0);

        // Open the second file
        FileInputStream file2 = new FileInputStream(new File(file2Path));
        XSSFWorkbook workbook2 = new XSSFWorkbook(file2);
        Sheet sheet2 = workbook2.getSheetAt(0);

        // Create a map of unique keys from first file
        Map<String, Boolean> map = new HashMap<String, Boolean>();
        for (Row row : sheet1) {
            Cell key1 = row.getCell(0);
            Cell key2 = row.getCell(1);
            if (key1 != null && key2 != null) {
                map.put(key1.getStringCellValue() + key2.getStringCellValue(), true);
            }
        }

        // Iterate over the second file and delete matching rows
        Iterator<Row> iterator2 = sheet2.iterator();
        while (iterator2.hasNext()) {
            Row row = iterator2.next();
            Cell key1 = row.getCell(1);
            Cell key2 = row.getCell(2);
            if (key1 != null && key2 != null) {
                String key = key1.getStringCellValue() + key2.getStringCellValue();
                if (map.containsKey(key)) {
                    iterator2.remove();
                }
            }
        }

        // Write the changes to the second file
        FileOutputStream fileOut = new FileOutputStream(file2Path);
        System.out.println("Data Removed Successfully");
        workbook2.write(fileOut);
        fileOut.close();

        // Close the workbooks and input streams
        workbook1.close();
        workbook2.close();
        file1.close();
        file2.close();
    }
}

