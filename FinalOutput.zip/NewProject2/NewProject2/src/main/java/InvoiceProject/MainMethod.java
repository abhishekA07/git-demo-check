//package InvoiceProject;
//import java.nio.file.Path;
//import java.nio.file.Paths;
//import java.util.List;
//public class MainMethod {
////	public static void StartingClass() throws Exception {
//	public static void main(String args []) throws Exception {
////	    System.out.println("Enter the directory Path:\n");
////	    Scanner s = new Scanner(System.in);
//		String dirPath = "D:\\Invoices";
//		String dirPath2 = "D:\\PSLInvoiceReport";
//		String extractedExcelFromPDF = "";
//		boolean checkForMatchedExcel = false;
//		String destDir = "D://MovedExcels";
//		List<String> perExcelFiles = extractedFilePath.getPSLFiles(dirPath2);
//		for(String itr:perExcelFiles)
//		{  
//			String Path = LoadExcelData.PSLInvoiceExtractor(itr);
//			ExcelFilesAppender.Appender(Path);	
//		}
////		MovingPSLfiles.movingPSlfiles(perExcelFiles);
//		List<String> pdfFiles = extractedFilePath.getPdfFiles(dirPath);
//		List<String> excelFiles = extractedFilePath.getExcelFiles(dirPath);
//		//PDF files are extracted from here
//		if(pdfFiles.size()>0 && excelFiles.size()>0) {
//		  for(String itr:pdfFiles)
//		  {
//			  String extractedPDFPath = FileValidatorTwo.PdfExtraction(itr);
//			  extractedExcelFromPDF = Appender.ExcelAppender(extractedPDFPath);
//		  }
//		  System.out.println("All PDF Files are merged successfully!");
////		Extracted PDF files are moved to another locations
////		  MovingPDFfiles.movingPDFs(pdfFiles);
//		  System.out.println("All PDF Files are moved successfully.");
//		  
//		  //Iterating over excel files and comparing with extracted PDFexcel 
//		  //if matches then moving to new dir else continuing to check for match
//		 for(String itr:excelFiles)
//		 {//iterating over all beelines and comparing with extracted pdf data
//			 String extractedExcelFromBeeline = ExcelExtractor.ExcelExtraction(itr);
//			 checkForMatchedExcel = Comparator2.ComparatorTwo(extractedExcelFromPDF,extractedExcelFromBeeline);
//			 if(checkForMatchedExcel)
//			 {
//				 	Path sourcePath = Paths.get(itr);
//		            // get the destination file path
//		            Path destPath = Paths.get(destDir, sourcePath.getFileName().toString());
//		            // move the file to the destination directory
////		            Files.move(sourcePath, destPath);
//			 }
//			 System.out.println("Matched Excel Files are moved successfully to: "+destDir);
//		 }
//		}else
//		{
//			System.out.println("Files not found in: "+dirPath);
//		}
//	}
//}
