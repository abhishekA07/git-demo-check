package InvoiceProject;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class LoadExcelData {
	public static String PSLInvoiceExtractor(String pathOfInvoice) throws IOException {
//	public static void main(String args [])throws IOException{
		List<Object>invoiceList=new ArrayList<Object>();
		ArrayList<Object>headerList=new ArrayList<Object>();
		headerList.add("Invoice ID");
		headerList.add("Week Ending Date");
		headerList.add("Project Name");
		invoiceList.add(headerList);
		//System.out.println(headerList);
//		System.out.println(pathOfInvoice);
		FileInputStream file= new FileInputStream(new File(pathOfInvoice));
		XSSFWorkbook workbook=new XSSFWorkbook(file);
		XSSFSheet sheet=workbook.getSheetAt(0);
		XSSFRow row = sheet.getRow(0);
		XSSFCell cell=null;
		int colNum1=-1;
		int colNum2=-1;
		int colNum3=-1;
		for(int i=0;i<row.getLastCellNum();i++) {
			if(row.getCell(i).getStringCellValue().trim().equals("Invoice Num")) {
				colNum1=i;
			}
			if(row.getCell(i).getStringCellValue().trim().equals("Invoice Cycle")) {
				colNum2=i;
			}
			if(row.getCell(i).getStringCellValue().trim().equals("Project Contract Name")) {
				colNum3=i;
			}
		}
		//System.out.println(colNum1);
		//System.out.println(colNum2);
		for(int i=1;i<sheet.getLastRowNum();i++) {
			ArrayList<Object> dataList=new ArrayList<Object>();
			row=sheet.getRow(i);
			cell=row.getCell(colNum1);
			switch(cell.getCellType())
			{
            case NUMERIC:
            			 String str1 = Double.toString(cell.getNumericCellValue());
            			 System.out.print(str1);
            			 break;
            case BOOLEAN:System.out.print(cell.getBooleanCellValue());break;
            case STRING:System.out.print(cell.getStringCellValue());
            dataList.add(cell.getStringCellValue());
            break;
			default:
				break;

            }
			cell=row.getCell(colNum2);
			System.out.print("|");
			switch(cell.getCellType())
			{
            case NUMERIC:System.out.print(cell.getNumericCellValue());
            break;
            case BOOLEAN:System.out.print(cell.getBooleanCellValue());
            break;
            case STRING:
            	int c=0;
            			String[] s1=cell.getStringCellValue().split("to");
            			//System.out.print(s1[1].trim());
            			for(String s2:s1) {
            				c++;
            				if(c==1) {
            					continue;
            				}
            				else {
            				s2=s2.trim();
            				//s2=s2.replace(" ", "/");
            				//System.out.print(s2);
            				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd MMM yyyy", Locale.ENGLISH);
            		        LocalDate date = LocalDate.parse(s2, formatter);

            		        DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("MM/dd/yyyy");
            		        String dateToString = date.format(formatter2);
            		        System.out.print(dateToString);
            		        dataList.add(dateToString);
            		        
            				}
            			}
            			break;
			default:
				break;
			}
            			cell=row.getCell(colNum3);
            			switch(cell.getCellType())
            			{
                        case NUMERIC:
                        			 String str1 = Double.toString(cell.getNumericCellValue());
                        			 System.out.print(str1);
                        			 break;
                        case BOOLEAN:System.out.print(cell.getBooleanCellValue());break;
                        case STRING:System.out.print(cell.getStringCellValue());dataList.add(cell.getStringCellValue());break;
						default:
							break;

                        }
            
			System.out.println();
			invoiceList.add(dataList);
			//String id=String.valueOf(cell.getStringCellValue());
			//system.out.println(id);
		}
		
		//System.out.println(invoiceList);
		file.close();
		workbook.close();
		//System.out.println(invoiceList);
		
		
		XSSFWorkbook workbook1=new XSSFWorkbook();
	    XSSFSheet sheet1=workbook1.createSheet();
	    int rownum=0;
	    for(Object bill:invoiceList) {
	    	//System.out.println(bill);
	    	XSSFRow row1=sheet1.createRow(rownum++);
	    	int cellnum=0;
	    	Object[] objects =  ((List<Object>) bill).toArray();
	    	for (Object obj1 : objects) {
	            //System.out.print(obj1 + " ");
	    		//System.out.println();
	    		XSSFCell cell1=row1.createCell(cellnum++);
	    		if(obj1 instanceof String) {
	    			cell1.setCellValue((String)obj1);
	    		}
	    		if(obj1 instanceof Integer) {
	    			cell1.setCellValue((Integer)obj1);
	    		}
	    		if(obj1 instanceof Boolean) {
	    			cell1.setCellValue((Boolean)obj1);
	    		}	
	    	}
	    }
	    String fileLocation = "D:\\DataForTest1\\ExtractedFile.xlsx";
	    FileOutputStream fos=new FileOutputStream(fileLocation);
	    workbook1.write(fos);
	    fos.close();
	    System.out.println("File Written Successfully");
	    return fileLocation;
	}
}
		
	

