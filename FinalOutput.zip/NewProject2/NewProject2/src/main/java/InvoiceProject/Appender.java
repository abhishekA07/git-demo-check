package InvoiceProject;
import java.io.*;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.*;

public class Appender {
    public static String ExcelAppender(String f1) throws IOException {
        // Open the first workbook
        FileInputStream file1 = new FileInputStream(new File(f1));
        XSSFWorkbook workbook1 = new XSSFWorkbook(file1);
        XSSFSheet sheet1 = workbook1.getSheetAt(0);

        // Open the second workbook
        FileInputStream file2 = new FileInputStream(new File("D:\\Test1\\ExtractedPDFData.xlsx"));
        XSSFWorkbook workbook2 = new XSSFWorkbook(file2);
        XSSFSheet sheet2 = workbook2.getSheetAt(0);

        // Create a new workbook to append the data
        XSSFWorkbook workbook = new XSSFWorkbook();
        XSSFSheet sheet = workbook.createSheet();

        // Copy the headers from the first sheet
        Row headerRow = sheet.createRow(0);
        Row firstHeaderRow = sheet1.getRow(0);
        for (int i = 0; i < firstHeaderRow.getLastCellNum(); i++) {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(firstHeaderRow.getCell(i).getStringCellValue());
        }

        // Copy the data from the first sheet
        int rowNumber = 1;
        for (Row row : sheet1) {
            if (row.getRowNum() == 0) {
                continue; // skip header row
            }
            Row newRow = sheet.createRow(rowNumber++);
            for (int i = 0; i < row.getLastCellNum(); i++) {
                Cell cell = newRow.createCell(i);
                cell.setCellValue(row.getCell(i).getStringCellValue());
            }
        }

        // Copy the data from the second sheet
        for (Row row : sheet2) {
            if (row.getRowNum() == 0) {
                continue; // skip header row
            }
            Row newRow = sheet.createRow(rowNumber++);
            for (int i = 0; i < row.getLastCellNum(); i++) {
                Cell cell = newRow.createCell(i);
                cell.setCellValue(row.getCell(i).getStringCellValue());
            }
        }
        // Write the merged data to a new file
        String path3 = "D:\\Test1\\ExtractedPDFData.xlsx";
        FileOutputStream outputStream = new FileOutputStream(path3);
        workbook.write(outputStream);
        outputStream.close();
        // Close all the workbooks
        workbook.close();
        workbook1.close();
        workbook2.close();
        file1.close();
        file2.close();
        return path3;
    }
}


