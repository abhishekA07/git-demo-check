package InvoiceProject;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
public class extractedFilePath {
//    private static String dirPath = "D:\\Invoices";
//    public static void main(String[] args) {
//    	public static void extFilePath(String dirPath) {
//        ScheduledExecutorService executor = Executors.newSingleThreadScheduledExecutor();
//        executor.scheduleAtFixedRate(new Runnable() {
//            public void run() {
//                List<String> pdfFiles = getPdfFiles();
//                List<String> excelFiles = getExcelFiles();
//                List<String> perExcelFiles = getPersistentExcelFiles();
//                System.out.println("PDF Invoices");
//                for(String itr:pdfFiles)
//                {
//                	System.out.println(itr);
//                }
//                System.out.println("\nExcel Invoices");
//                for(String itr:excelFiles)
//                {
//                	System.out.println(itr);
//                }
//                System.out.println("\nPersistent Invoices");
//                for(String itr:perExcelFiles)
//                {
//                	System.out.println(itr);
//                }
//            }
        //}, 2, 2, TimeUnit.DAYS);
   // }
    public static List<String> getPdfFiles(String dirPath) {
        List<String> pdfFiles = new ArrayList<String>();
        File dir = new File(dirPath);
        
        if (dir.exists() && dir.isDirectory()) {
            
            File[] files = dir.listFiles();
            for (File file : files) {
                
                if (file.isFile() && file.getName().endsWith(".PDF") && file.getName().contains("Payment Advice for")) {
                    pdfFiles.add(file.getPath());
                }
            }
        }
        return pdfFiles;
    }
      public static List<String> getExcelFiles(String dirPath) {

        List<String> excelFiles = new ArrayList<String>();
        File dir = new File(dirPath);
        
        if (dir.exists() && dir.isDirectory()) {
            
            File[] files = dir.listFiles();
            for (File file : files) {
                
                if (file.isFile() && file.getName().endsWith(".xlsx") && file.getName().contains("Beeline_Supplier_Payment_Register_PIMCO")) {
                  
                    excelFiles.add(file.getPath());
                }
            }
        }
        return excelFiles;
    }
    public static List<String> getPSLFiles(String dirPath) {
        List<String> excelFiles = new ArrayList<String>();
        File dir = new File(dirPath);
        
        if (dir.exists() && dir.isDirectory()) {
            File[] files = dir.listFiles();
            for (File file : files) {
                
                if (file.isFile() && file.getName().endsWith(".xlsx") && file.getName().contains("InvoiceReport")) {
                  
                    excelFiles.add(file.getPath());
                }
            }
        }
        return excelFiles;
    }
}
