package InvoiceProject;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
//Working Code
public class Comparator2 {
//    public static void main(String[] args) throws InvalidFormatException, IOException, EncryptedDocumentException, ParseException {
        // Define the path of the two Excel files
    	public static boolean ComparatorTwo(String PDFExcelPath,String BeeLineExcelPath ) throws Exception {
        boolean returnToMain = false;
        String ColumnName = "Invoice Number";
        try {
        	returnToMain =  compareExcels(PDFExcelPath,BeeLineExcelPath ,ColumnName); 
          } catch (IOException e) {
            System.out.println("Error while comparing excel files: " + e.getMessage());
          }
        return returnToMain;
        }
    private static int getColumnIndex(Sheet sheet, String columnName) {
        Row headerRow = sheet.getRow(0);
        for (Cell headerCell : headerRow) {
            if (headerCell.getStringCellValue().equals(columnName)) {
                return headerCell.getColumnIndex();
            }
        }
        return -1;
      }
        // Load the two workbooks
    private static boolean compareExcels(String PDFExcelPath, String BeeLineExcelPath, String columnName) throws Exception {
    	Workbook workbook1 = WorkbookFactory.create(new File(PDFExcelPath));
        Workbook workbook2 = WorkbookFactory.create(new File(BeeLineExcelPath));
        boolean FileMatches = false;
        int rowNumInt = -1;
        // Get the first sheet from each workbook
        Sheet sheet1 = workbook1.getSheetAt(0);
        Sheet sheet2 = workbook2.getSheetAt(0);
        // Create a list to store the cell data of the matched rows
        List<String[]> matchedRows = new ArrayList<String[]>();
        List<String> headerList = new ArrayList<String>();
        headerList.add("Contractor");
        headerList.add("Project");
        headerList.add("Cost Center");
        headerList.add("Week Ending Date");
        headerList.add("Pay Code");
        headerList.add("Units");
        headerList.add("Bill Rate");
        headerList.add("Gross Amount");
        headerList.add("Volume Discount");
        headerList.add("Prompt Pay Discount");
        headerList.add("Program Fee");
        headerList.add("Tax Amount");
        headerList.add("Net Supplier Payable");
        headerList.add("Statement Date");
        headerList.add("Invoice Number");
        headerList.add("Total Amount");
        headerList.add("Payment Number");
        headerList.add("Payment Date");
        // Find the index of the common column in both sheets
        int columnIndex1 = getColumnIndex(sheet1, columnName);
        int columnIndex2 = getColumnIndex(sheet2, columnName);
        
        if (columnIndex1 == -1 || columnIndex2 == -1) {
            System.out.println("Could not find the specified column name in one of the sheets.");
          }

        // Iterate through the rows of the first sheet
        for (Row row1 : sheet1) {
            if (row1.getRowNum() == 0) {
                continue;
            }

            Cell cell1 = row1.getCell(columnIndex1);
            String cellValue1 = cell1.getStringCellValue();
//            String date1=DateFormatChange.removeZeroFromFirstPart(cellValue1);
//            date1=DateFormatChange.removeZeroFromSecondPart(date1);
	            for (Row row2 : sheet2) {
	                if (row2.getRowNum() == 0) {
	                    continue;
	                }
                Cell cell2 = row2.getCell(columnIndex2);
                String cellValue2 = cell2.getStringCellValue();
//                String date2=DateFormatChange.removeZeroFromFirstPart(cellValue2);
//                date2=DateFormatChange.removeZeroFromSecondPart(date2);
                
                int i=0;
                // Check if the values in the common column match
                if (cellValue1.equals(cellValue2)) {
                	rowNumInt=row2.getRowNum();
                	String[] values = new String[row1.getLastCellNum() + row2.getLastCellNum()-2];
                	for (Cell cell : row2) {
	                    if (cell.getColumnIndex() != columnIndex2) {
	                        values[i++] = cell.getStringCellValue();
	                    }
	                }
                	for (Cell cell : row1) {
                        if (cell.getColumnIndex() != columnIndex1+1) {
                            values[i++] = cell.getStringCellValue();
                        }
                    }
	                
                matchedRows.add(values);
            }
        }
    } 
        if(rowNumInt>=0)
	    {
    	int newRowNum=rowNumInt;
    	String sheetName = sheet1.getSheetName(); 
        DeletionCheck.deleteRow(PDFExcelPath, sheetName, newRowNum);
        FileMatches=true;
        String file1Output = "D:\\Test1\\StatementDateCompareOutput.xlsx";
	    try {
	    	FileOutputStream outputStream = new FileOutputStream(file1Output);
	        // Create a new workbook and sheet
	        XSSFWorkbook outputWorkbook = new XSSFWorkbook();
	        XSSFSheet outputSheet = outputWorkbook.createSheet();
	
	        // Write the headers to the output sheet
	        XSSFRow headerRow = outputSheet.createRow(0);
	        for (int i = 0; i < headerList.size(); i++) {
	            XSSFCell headerCell = headerRow.createCell(i);
	            headerCell.setCellValue(headerList.get(i));
	        }
	
//	        // Write the matched rows to the output sheet
	        for (int i = 0; i < matchedRows.size(); i++) {
	            XSSFRow outputRow = outputSheet.createRow(i + 1);
	            String[] values = matchedRows.get(i);
	            for (int j = 0; j < values.length; j++) {
	                XSSFCell outputCell = outputRow.createCell(j);
	                outputCell.setCellValue(values[j]);
	            }
	        }
        // Save the output workbook
        outputWorkbook.write(outputStream);
        System.out.println("File written successfully.");
        Comparator3.weekEndingDateCheck(file1Output);
	    } catch (IOException e) {
	        System.err.println("Error writing output file: " + e.getMessage());
	    }
	    }
        else
        {
        	System.out.println("Row Not Found");
        }
    // Close the workbooks
    workbook1.close();
    workbook2.close();
    // Print the cell data of the matched rows
    for (String[] values : matchedRows) {
        for (String value : values) {
            System.out.print(value + " | ");
        }
        System.out.println();
    }   
    
	    return FileMatches;
	    }
}

