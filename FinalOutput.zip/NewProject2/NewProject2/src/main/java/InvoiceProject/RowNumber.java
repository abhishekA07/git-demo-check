package InvoiceProject;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class RowNumber {
    public static void getRowNumber(List<String> rowNumList) throws IOException {
    	String filePath = "D:\\DataForTest1\\RowNumList.xlsx";
    	FileInputStream fileIn = new FileInputStream(filePath);
        XSSFWorkbook workbook = new XSSFWorkbook(fileIn);
        Sheet sheet = workbook.getSheetAt(0);

        // Get the last row number and add 1 to get the next available row
        int lastRowNum = sheet.getLastRowNum();
        int nextRowNum = lastRowNum + 1;

        // Add the numbers to the next available row
        for (String number : rowNumList) {
            Row row = sheet.createRow(nextRowNum++);
            Cell cell = row.createCell(0);
            cell.setCellValue(number);
        }

        // Save the workbook to the same file
        FileOutputStream fileOut = new FileOutputStream(filePath);
        workbook.write(fileOut);
        fileOut.close();

        // Close the workbook and file input stream
        workbook.close();
        fileIn.close();
}
}

