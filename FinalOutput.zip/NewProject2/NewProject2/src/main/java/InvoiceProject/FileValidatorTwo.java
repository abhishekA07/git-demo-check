package InvoiceProject;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class FileValidatorTwo {
    public static String PdfExtraction(String pdfFile)throws Exception {
		List<Object>consilidatedBill =new ArrayList<Object>();
		ArrayList<Object> fileHeadings=new ArrayList<Object>();
		fileHeadings.add("Invoice Number");
		fileHeadings.add("Statement Date");
		fileHeadings.add("Amount");
		fileHeadings.add("Payment Number");
		fileHeadings.add("Payment Date");
		consilidatedBill.add(fileHeadings);
		String refid=null;
		String bdate=null;
		String[] details_arr=null;
		String billingDetails=null;
		File file=new File(pdfFile);
		FileInputStream fis2=new FileInputStream(file);
		PDDocument pdf2=PDDocument.load(fis2);
		PDFTextStripper pdts1=new PDFTextStripper();
		String docText1=pdts1.getText(pdf2);
		String[]stringList1=docText1.split("\n");
		for(String s1:stringList1) {
            if(s1.contains("PIMCOBEE")) {
            	ArrayList<Object> consilidatedBill1=new ArrayList<Object>();
                //System.out.println(s1);
            	details_arr=s1.split(" ");
                refid=s1.split(" ")[1];
                bdate=s1.split(" ")[2];
                refid=refid.substring(((refid.length())-6), refid.length());
        	    consilidatedBill1.add(refid);
        	    consilidatedBill1.add(bdate);
        	    consilidatedBill1.add(details_arr[(details_arr.length)-2]);
        	    billingDetails=stringList1[(stringList1.length)-1];
        	    consilidatedBill1.add(billingDetails.split(" ")[0]);
        		consilidatedBill1.add(billingDetails.split(" ")[1]);
        		consilidatedBill.add(consilidatedBill1);
            }
        }
		pdf2.close();
	    fis2.close();
	    XSSFWorkbook workbook=new XSSFWorkbook();
	    XSSFSheet sheet=workbook.createSheet();
	    int rownum=0;
	    for(Object bill:consilidatedBill) {
	    	//System.out.println(bill);
	    	XSSFRow row=sheet.createRow(rownum++);
	    	int cellnum=0;
	    	Object[] objects =  ((List<Object>)bill).toArray();
	    	for (Object obj1 : objects) {
	    		XSSFCell cell=row.createCell(cellnum++);
	    		if(obj1 instanceof String) {
	    			cell.setCellValue((String)obj1);
	    		}
	    		if(obj1 instanceof Integer) {
	    			cell.setCellValue((Integer)obj1);
	    		}
	    		if(obj1 instanceof Boolean) {
	    			cell.setCellValue((Boolean)obj1);
	    		}		
	    	}
	    }
	    String fileLocation1="D:\\DataForTest1\\BeelinePDF.xlsx";
	    FileOutputStream fos=new FileOutputStream(fileLocation1);
	    workbook.write(fos);
	    fos.close();
	    return fileLocation1;
}
}
