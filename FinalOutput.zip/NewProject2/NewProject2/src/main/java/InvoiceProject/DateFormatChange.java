package InvoiceProject;

public class DateFormatChange{
	    public static String removeZeroFromFirstPart(String dateString) {
	        if (dateString.charAt(0) == '0') {
	            dateString = dateString.substring(1);
	        }
	        return dateString;
	    }
	    public static String removeZeroFromSecondPart(String dateString) {
	        String[] dateParts = dateString.split("/");
	        if (dateParts[1].charAt(0) == '0') {
	            dateParts[1] = dateParts[1].substring(1);
	        }
	        dateString = String.join("/", dateParts);
	        return dateString;
	    }
	}
