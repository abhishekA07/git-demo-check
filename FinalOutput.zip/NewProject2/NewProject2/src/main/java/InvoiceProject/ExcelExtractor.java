package InvoiceProject;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
public class ExcelExtractor {
//	public static void main(String[] args) throws IOException {
		public static String ExcelExtraction (String excelFile)throws IOException  {
			List<Object> headerList=new ArrayList<Object>();
			String invoice_no=null;
			String refid1=null;
			String refid2=null;
		    ArrayList<String> subDataList=new ArrayList<String>();
            ArrayList<String> subDataList1=new ArrayList<String>();
		        try {
		        	
		            // Open the Excel file
		            FileInputStream file = new FileInputStream(new File(excelFile));
		            Workbook workbook = WorkbookFactory.create(file);    
		            // Get the first sheet
		            Sheet sheet = workbook.getSheetAt(0);
		          
		            Row rows = sheet.getRow(11);
		            int colCount=rows.getLastCellNum();
		            for(int i=0;i<colCount;i++) {
		            	Cell cell=rows.getCell(i);
		            	if(cell != null) {
		                    subDataList.add(cell.getStringCellValue().trim().split(":")[0].trim());
		                    subDataList1.add(cell.getStringCellValue().trim().split(":")[1].trim());
		            		break;
		            	}
		            	else {
		            		continue;
		            	}
		            }
		            rows=sheet.getRow(9);
		            int lastCellRow=rows.getLastCellNum();
		            for(int i=0;i<lastCellRow;i++) {
		            	Cell cell=rows.getCell(i);
		            	if(cell != null) {
		            		if(cell.getStringCellValue().contains("Currency: USD (US Currency)")) {
		            			continue;
		            		}
		            		invoice_no=cell.getStringCellValue();
		            	}
		           
		            	else {
		            		continue;
		            	}
		            }
		            invoice_no=invoice_no.split(" ")[2];
		            

		            refid1=invoice_no.substring(((invoice_no.length())-2),invoice_no.length() );
		            //System.out.println(refid1);
		            refid2=invoice_no.substring(3, 7);
		            refid2=refid2.concat(refid1);
//		            System.out.println(refid2);
		            subDataList.add("Invoice Number");
		            subDataList1.add(refid2);
		            
		            // Iterate over the rows
		            for (Row row : sheet) {
		            	ArrayList<Object> detailList=new ArrayList<Object>();
		                // Iterate over the cells
		            	//countRow++;
		            	if ((row.getRowNum()<14) || (row.getLastCellNum() == -1) ){
		            		
		            		continue;
		            		}
		                for (Cell cell : row) {
		                    // Check if the cell contains a picture
		                	
		                    if (cell.getCellType() == CellType.STRING && cell.getStringCellValue().equalsIgnoreCase("image")){
		                        continue;
		                    }
		                    if (cell.getCellType() == CellType.STRING && cell.getStringCellValue().equals("PO")){
		                        continue;
		                    }
		                   
		       
		                    else {
		                        // Print the cell contents
		                    	String temp=cell.toString().trim();
		                    	//System.out.println(temp.contains("\n"));
		                    	if(/*temp.length()==0 ||*/ temp=="") {
		                    		continue;
		                    	}
		                    	
		                    	
		                    	else {
		                   
		                    		detailList.add(temp);
		                    		}
		                    	
//		                        System.out.print(cell.toString() + "|");
		                    }
		                }
		                //System.out.println();
		                headerList.add(detailList);
		            }
		            file.close();
		        } catch (Exception e) {
		            e.printStackTrace();
		        }
		        XSSFWorkbook workbook1=new XSSFWorkbook();
			    XSSFSheet sheet1=workbook1.createSheet();
			    int rownum=0;
			    int counter=0;
			    int size = headerList.size();
			    for(Object newExcelList:headerList) {
			    	counter++;
			    	if(counter<(size-3)) {
			    	//System.out.println(bill);
			    	XSSFRow row1=sheet1.createRow(rownum++);
			    	int cellnum=0;
			    	Object[] objects =  ((List<Object>)newExcelList ).toArray();
			    	for (Object obj1 : objects) {
			            //System.out.print(obj1 + " ");
			    		//System.out.println();
			    		XSSFCell cell1=row1.createCell(cellnum++);
			    		if(obj1 instanceof String) {
			    			cell1.setCellValue((String)obj1);
			    		}
			    		if(obj1 instanceof Integer) {
			    			cell1.setCellValue((Integer)obj1);
			    		}
			    		if(obj1 instanceof Boolean) {
			    			cell1.setCellValue((Boolean)obj1);
			    		}
			    	}
			    	
			    
			    }
		}

			    String fileLocation="D:\\DataForTest1\\BeelineModifiedPdf.xlsx";
			    FileOutputStream fos=new FileOutputStream(fileLocation);
			    workbook1.write(fos);
			    fos.close();
			    FileInputStream files=new FileInputStream(new File("D:\\DataForTest1\\BeelineModifiedPdf.xlsx"));
			    XSSFWorkbook wkbook=new XSSFWorkbook(files);
			    XSSFSheet sheetb=wkbook.getSheetAt(0);
			    int hRow=sheetb.getLastRowNum();
			    int hCol=sheetb.getRow(0).getLastCellNum();
			    int hcol1=hCol;
			    for(int i=0;i<=hRow;i++) {
			    	XSSFRow r1=sheetb.getRow(i);
			    	if(r1==null) {
			    		r1=sheetb.createRow(i);
			    	}
			    	for(int j=0;j<subDataList.size();j++)
			      {
			    		XSSFCell c1=r1.createCell(hCol++);
//			    		System.out.println(subDataList.get(j));
			    		if(i==0) {
			    		c1.setCellValue(subDataList.get(j));}
			    		else {
			    			c1.setCellValue(subDataList1.get(j));
			    		}
			    	}
			    	hCol=hcol1;
			    	}
//			    System.out.println(subDataList);
			    String fileLocation2="D:\\DataForTest1\\BeelineExcel.xlsx";
			    FileOutputStream fos2=new FileOutputStream(fileLocation2);
			    wkbook.write(fos2);
			    wkbook.close();
			    fos2.close();
			    System.out.println("File Written Successfully"); 
			    return fileLocation2;
	}
}

