package InvoiceProject;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
public class MovingPSLfiles {
	    public static void movingPSlfiles(List<String> filePaths) throws IOException {
	        // destination directory
	    	String sourceDir = "D:\\PSLInvoiceReport";
	        String destDir = "D:\\MovedPSLFiles";
	        try {
	        // iterate over each file path
	        for (String filePath : filePaths) {
	            // get the source file path
	            Path sourcePath = Paths.get(filePath);
	            // get the destination file path
	            Path destPath = Paths.get(destDir, sourcePath.getFileName().toString());
	            // move the file to the destination directory
	            Files.move(sourcePath, destPath);
	        }
	        System.out.println("File moved from " + sourceDir + " to " + destDir);
	    }catch(IOException e)
	        {
	    		System.out.println("Files are not moved.");
	        }
	}
}

