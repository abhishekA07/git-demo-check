package InvoiceProject;
import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class ListofRowNumbers {
    public static List<Integer> createListOfRows() {
 	   String filePath = "D:\\DataForTest1\\RowNumList.xlsx";
        // Create a list to store the values from the specified column
        List<Integer> columnValues = new ArrayList<Integer>();
        // Specify the column number to extract (0-based index)
        int columnNumber = 0;
        
        try {
            // Create a FileInputStream to read the Excel file
            FileInputStream fileInputStream = new FileInputStream(new File(filePath));
            
            // Create a Workbook object from the fileInputStream
            Workbook workbook = WorkbookFactory.create(fileInputStream);
            
            // Get the first sheet from the workbook
            Sheet sheet = workbook.getSheetAt(0);
            
            // Iterate through each row in the sheet
            Iterator<Row> rowIterator = sheet.iterator();
            while (rowIterator.hasNext()) {
                Row row = rowIterator.next();
                
                // Get the cell value from the specified column for each row
                Cell cell = row.getCell(columnNumber);
                if (cell != null) {
                    columnValues.add((int) cell.getNumericCellValue());
                }
            }
            // Print the values in the list
            for(Integer it :columnValues) {
            System.out.println("Column Value: "+it);
            }
            // Close the workbook and fileInputStream
            workbook.close();
            fileInputStream.close();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
		return columnValues; 
    }
    
}

